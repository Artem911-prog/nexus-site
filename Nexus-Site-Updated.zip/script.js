document.getElementById("download-btn").addEventListener("click", function() {
    alert("Скоро здесь появится ссылка на скачивание!");
});